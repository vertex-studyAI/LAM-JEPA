# Anonymous reproduction supplement

This archive contains the code and instructions needed to reproduce the paper's
main ARC-Challenge development-validation result without exposing author,
institution, repository, or submission metadata.

## Scientific boundary

- Use ARC-Challenge train and validation only.
- Do not download or evaluate the ARC test split for this failed hypothesis line.
- Use seeds 1, 2, 3, 4, and 5.
- Use 20 epochs, batch size 32, learning rate 0.0003, one model step, and CPU.
- Preserve null/adverse outcomes. Do not change thresholds, seeds, splits, or
  evaluation policy after seeing a result.
- Low-order floating-point probabilities may drift across runners. The retained
  claim is aggregate-result and verifier reproduction, not byte-identical raw
  probabilities or checkpoints.

## Environment

The retained scientific runs used Python 3.11 and CPU PyTorch. Exact physical
CPU model metadata was not retained, so this supplement does not claim
hardware-bitwise reproduction.

Create an isolated environment and install the declared dependencies:

~~~bash
python -m venv .venv
. .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install torch --index-url https://download.pytorch.org/whl/cpu
python -m pip install -e '.[external-benchmarks]'
python -c 'import torch; assert not torch.cuda.is_available()'
~~~

## Obtain the allowed data

~~~bash
mkdir -p work/arc-data
python scripts/data/download_arc_challenge.py \
  --splits train validation \
  --out-dir work/arc-data
test ! -e work/arc-data/arc-challenge-test.parquet
~~~

Verify the frozen data/protocol boundary:

~~~bash
python scripts/ci/verify_arc_protocol_v3.py \
  --protocol protocols/arc_challenge_v3.json \
  --dataset-manifest data/manifests/arc_challenge.json \
  --report work/arc-protocol-v3-verification.json
~~~

## Reproduce the five-seed full controls result

~~~bash
python scripts/benchmark/run_arc_protocol_v3_controls.py \
  --train work/arc-data/arc-challenge-train.parquet \
  --validation work/arc-data/arc-challenge-validation.parquet \
  --seeds 1 2 3 4 5 \
  --epochs 20 \
  --batch-size 32 \
  --learning-rate 0.0003 \
  --model-steps 1 \
  --train-limit 0 \
  --validation-limit 0 \
  --device cpu \
  --out work/full-controls.json

python scripts/ci/verify_arc_protocol_v3_full_controls.py \
  --results work/full-controls.json \
  --protocol protocols/arc_challenge_v3.json \
  --train work/arc-data/arc-challenge-train.parquet \
  --validation work/arc-data/arc-challenge-validation.parquet \
  --report work/full-controls-verification.json
~~~

## Reproduce the capacity-matched supervised comparison

~~~bash
python scripts/benchmark/run_arc_matched_baseline_v3.py \
  --run-stage validation_stage \
  --train work/arc-data/arc-challenge-train.parquet \
  --validation work/arc-data/arc-challenge-validation.parquet \
  --seeds 1 2 3 4 5 \
  --epochs 20 \
  --batch-size 32 \
  --learning-rate 0.0003 \
  --model-steps 1 \
  --device cpu \
  --match-tolerance 0.01 \
  --out work/matched-baseline.json

python scripts/ci/verify_arc_matched_baseline.py \
  --results work/matched-baseline.json \
  --report work/matched-baseline-base-verification.json

python scripts/ci/verify_arc_matched_baseline_v3.py \
  --results work/matched-baseline.json \
  --base-verification work/matched-baseline-base-verification.json \
  --protocol protocols/arc_challenge_v3.json \
  --train work/arc-data/arc-challenge-train.parquet \
  --validation work/arc-data/arc-challenge-validation.parquet \
  --expected-stage validation_stage \
  --report work/matched-baseline-v3-verification.json
~~~

Both matched-baseline verifiers must pass. Compare the aggregate outputs against EXPECTED_RESULTS.json. Small
representation-level floating-point differences are acceptable only when the
aggregate scientific conclusion and verifier verdict remain unchanged.

## Interpretation boundary

The expected result is negative/inconclusive for this frozen implementation and
protocol. It does not establish general failure of JEPA methods, vector
quantization, planners, or representation learning. The locked ARC test remains
unused.
