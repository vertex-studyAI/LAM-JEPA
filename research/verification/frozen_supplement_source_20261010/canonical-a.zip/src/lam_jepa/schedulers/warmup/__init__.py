"""Support package for src/lam_jepa/schedulers/warmup.

This namespace keeps the research system modular and discoverable.
"""

__all__: list[str] = []
